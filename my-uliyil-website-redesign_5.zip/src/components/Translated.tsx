'use client';
import { useEffect, useState } from 'react';
export function useLanguage(){const [lang,setLang]=useState<'en'|'ml'>('en');useEffect(()=>{setLang(localStorage.getItem('uliyil-lang')==='ml'?'ml':'en');const listener=()=>setLang(localStorage.getItem('uliyil-lang')==='ml'?'ml':'en');window.addEventListener('uliyil-language',listener);return()=>window.removeEventListener('uliyil-language',listener)},[]);return lang;}
export function T({en,ml}:{en:string;ml:string}){const lang=useLanguage();return <>{lang==='ml'?ml:en}</>}
