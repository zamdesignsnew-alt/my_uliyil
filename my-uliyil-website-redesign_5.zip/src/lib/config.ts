export const site = {
  name: 'My Uliyil', tagline: 'Our Place. Our People. Our Future.',
  slogan: "Together, Let's Build a Better Ward.", sloganMl: 'ഒരുമിച്ച്, മികച്ചൊരു വാർഡ് കെട്ടിപ്പടുക്കാം.',
  location: 'Uliyil, Iritty Municipality, Kannur, Kerala, India', wardNumber: '19',
  councillor: { name: 'Shabna Teacher', role: 'Ward Councillor, Uliyil, Iritty Municipality', phone: '9497530282', email: 'councillorshabna@gmail.com', facebook: 'https://www.facebook.com/share/1AADvc8ALG/', instagram: 'https://www.instagram.com/shabnacouncillor/', portrait: '/images/shabna-teacher.jpg', welcome: 'Welcome to My Uliyil, a shared space for our community. This platform brings together local services, important announcements, development updates, and the voices of our residents. Together, we can make Uliyil more connected, accessible, and better for everyone.', welcomeMl: 'മൈ ഉളിയിൽലേക്ക് സ്വാഗതം. നമ്മുടെ സമൂഹത്തിനായുള്ള ഒരു കൂട്ടായ ഇടമാണിത്. പ്രാദേശിക സേവനങ്ങളും പ്രധാന അറിയിപ്പുകളും വികസന വിവരങ്ങളും നാട്ടുകാരുടെ ശബ്ദവും ഈ വേദിയിൽ ഒന്നിക്കുന്നു. ഒരുമിച്ച് ഉളിയിലിനെ കൂടുതൽ ബന്ധമുള്ളതും എല്ലാവർക്കും പ്രയോജനകരവുമായ സ്ഥലമാക്കാം.' },
  imagery: { hero: 'https://images.pexels.com/photos/14844302/pexels-photo-14844302.jpeg?auto=compress&cs=tinysrgb&w=2000', landscape: 'https://images.pexels.com/photos/770635/pexels-photo-770635.jpeg?auto=compress&cs=tinysrgb&w=1400', hills: 'https://images.pexels.com/photos/7322041/pexels-photo-7322041.jpeg?auto=compress&cs=tinysrgb&w=1400', community: '/images/community.jpg' },
  googleIdeaFormUrl: '', facebookPageId: '', facebookAccessTokenEnv: 'META_PAGE_ACCESS_TOKEN', mapUrl: 'https://www.openstreetmap.org/search?query=Uliyil%2C%20Iritty%2C%20Kerala',
  institutions: [] as {name:string;category:string;locality:string}[], projects: [] as {title:string;status:string}[], announcements: [] as {title:string;date:string}[], emergencyContacts: [{name:'India emergency response',number:'112',scope:'National emergency helpline'},{name:'Ambulance',number:'108',scope:'Kerala emergency ambulance service'},{name:'Fire & rescue',number:'101',scope:'India fire emergency helpline'}]
};
export const categories = [
  'Grocery stores','Bakeries & restaurants','Medical shops','Hardware stores','Electrical shops','Mobile shops','Tailoring & textiles','Printing & design','Beauty salons','Repair shops','Other local businesses','Auto-rickshaw drivers','Taxi drivers','Car rental','Other transport','Electricians','Plumbers','Mechanics','Painters','Carpenters','Appliance repair','Construction workers','Cleaning services','Hospitals','Clinics','Pharmacies','Ambulance providers','Other health services','Schools','Tuition centres','Training centres','Libraries','Educational services','Freelancers','Startups','Home-based businesses','Local professionals','Other services'
];
export const serviceGuides = [
  {name:'Welfare pensions', icon:'heart', description:'Guidance on available social security pension schemes.', url:'https://welfarepension.lsgkerala.gov.in/'},
  {name:'LIFE Mission housing', icon:'home', description:'Housing support information and programme updates.', url:'https://lifemission.kerala.gov.in/'},
  {name:'Ration cards', icon:'credit', description:'Find ration card services and application information.', url:'https://civilsupplieskerala.gov.in/'},
  {name:'Certificates', icon:'file', description:'Income, residence, birth and death certificate services.', url:'https://edistrict.kerala.gov.in/'},
  {name:'Scholarships', icon:'book', description:'Discover education assistance through official portals.', url:'https://scholarships.gov.in/'},
  {name:'Health assistance', icon:'plus', description:'Explore health coverage and assistance programmes.', url:'https://sha.kerala.gov.in/'},
  {name:'Senior citizen services', icon:'users', description:'Information on services for older residents.', url:'https://socialjustice.kerala.gov.in/'},
  {name:'Women & child welfare', icon:'sparkles', description:'Find support and programmes for women and children.', url:'https://wcd.kerala.gov.in/'},
  {name:'Disability assistance', icon:'access', description:'Access information about disability welfare.', url:'https://socialjustice.kerala.gov.in/'},
  {name:'Kudumbashree', icon:'flower', description:'Learn about neighbourhood groups and programmes.', url:'https://www.kudumbashree.org/'},
  {name:'Municipal services', icon:'building', description:'Explore local self-government digital services.', url:'https://ksmart.lsgkerala.gov.in/'},
];
