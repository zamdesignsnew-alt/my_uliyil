import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import { Shell } from '@/components/Shell';
import './globals.css';
export const metadata:Metadata={title:{default:'My Uliyil — Our Place. Our People. Our Future.',template:'%s | My Uliyil'},description:'The digital heart of Uliyil. Discover local services, community updates, helpful contacts, and connect with Ward Councillor Shabna Teacher in Iritty, Kannur, Kerala.',openGraph:{title:'My Uliyil',description:'Our Place. Our People. Our Future.',type:'website'},robots:{index:true,follow:true}};
export default function RootLayout({children}:{children:ReactNode}){return <html lang="en"><body><Shell>{children}</Shell></body></html>}
