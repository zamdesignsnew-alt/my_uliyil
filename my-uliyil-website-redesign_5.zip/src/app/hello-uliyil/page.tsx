import { Directory } from '@/components/Directory';
export const dynamic='force-dynamic';
export default function HelloUliyilPage(){return <Directory/>}
